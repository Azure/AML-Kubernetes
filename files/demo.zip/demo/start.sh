npm install -g local-web-server ts-node
npm install
npm start
module.exports = {
    directory: "./build",
    port: 3000,
    rewrite: [
      {
        from: "(/static/.*)",
        to: "$1"
      }
    ],
    spa: "index.html"
  };
  
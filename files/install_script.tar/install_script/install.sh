#!/bin/bash
kube_conf=$(cat ~/.kube/config)
installer_image=$1
compute_id=$2
node_pool=$3
app_insight=$4

kubectl apply -f ./cmaks-secret.yaml

kubectl apply -f https://raw.githubusercontent.com/Azure/kubernetes-volume-drivers/master/flexvolume/blobfuse/deployment/blobfuse-flexvol-installer-1.9.yaml

kubectl apply -f https://raw.githubusercontent.com/NVIDIA/k8s-device-plugin/1.0.0-beta6/nvidia-device-plugin.yml

kubectl delete configmap compute-config --wait=true --ignore-not-found=true
helm upgrade compute-map --set compute_id=$compute_id --set node_pool=$node_pool --set app_insight=$app_insight ./configmap-chart --wait --install

# uninstall installer installed before
install_num=$(helm list | grep install-job | wc -l)
if [[ $install_num != 0 ]]; then
    helm uninstall install-job
fi
kubectl delete job cmaks-init-job --wait=true --ignore-not-found=true

helm install install-job --set kube_conf="$kube_conf" --set image=$installer_image ./install-job-chart --wait

# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""This file will be removed soon in favor of azureml._common."""
# flake8: noqa

from azureml._common.async_utils.async_task import (basic_handler, noraise_handler, AsyncTask)

# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

""" introspect.py, A file that provides argument logic to the cli and Azure ML Workbench extensions."""

from __future__ import print_function


def introspect():
    pass

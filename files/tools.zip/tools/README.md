# Tools Used to Install/Upgrade/Uninstall the Agents in Cluster.

Before using the tools, please use `kubectl config use-context ${your_context}` changing your current context accordingly.

## Uninstall

To delete all the components installed by the agents, run the following command, replace the cluster name with your cluster name.

```bash
bash ./uninstall.sh ${cluster_name} azureml
```

## Install/Upgrade

To update or install components in your cluster.

1. Change the content in `installer/install-job-chart/values.yaml`, replace sub, resource etc with actual values.
2. Run the following command, replace the `${agent-installer-image}` with the installer's latest image.
   ```bash
   bash install.sh ${agent-installer-image}
   ```